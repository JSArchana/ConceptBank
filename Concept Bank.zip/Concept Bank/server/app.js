const express = require('express');
const app = new express();
app.get('/register',function(req,res){

});
app.listen(5000);