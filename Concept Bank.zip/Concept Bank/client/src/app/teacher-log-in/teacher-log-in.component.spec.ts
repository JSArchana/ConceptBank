import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TeacherLogInComponent } from './teacher-log-in.component';

describe('TeacherLogInComponent', () => {
  let component: TeacherLogInComponent;
  let fixture: ComponentFixture<TeacherLogInComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TeacherLogInComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TeacherLogInComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
