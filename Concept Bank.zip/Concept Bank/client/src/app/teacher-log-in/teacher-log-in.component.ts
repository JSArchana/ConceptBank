import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-teacher-log-in',
  templateUrl: './teacher-log-in.component.html',
  styleUrls: ['./teacher-log-in.component.css']
})
export class TeacherLogInComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
