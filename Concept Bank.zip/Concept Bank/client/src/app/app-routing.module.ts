import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {FormsModule} from '@angular/forms';
import {TeacherLogInComponent} from './teacher-log-in/teacher-log-in.component';
import {StudentLogInComponent} from './student-log-in/student-log-in.component';
import {RegisterComponent} from './register/register.component';

const routes: Routes = [{path:'teacher', component:TeacherLogInComponent},
{path:'student',component:StudentLogInComponent},
{path:'register',component:RegisterComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
