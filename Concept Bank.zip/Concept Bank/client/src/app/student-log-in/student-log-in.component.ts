import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-student-log-in',
  templateUrl: './student-log-in.component.html',
  styleUrls: ['./student-log-in.component.css']
})
export class StudentLogInComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
