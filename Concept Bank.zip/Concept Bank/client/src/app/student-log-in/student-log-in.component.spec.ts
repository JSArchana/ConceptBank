import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentLogInComponent } from './student-log-in.component';

describe('StudentLogInComponent', () => {
  let component: StudentLogInComponent;
  let fixture: ComponentFixture<StudentLogInComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StudentLogInComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentLogInComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
